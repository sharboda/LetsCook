function AS_FlexContainer_6226d99bda8046e6b85d3df47548f93e(eventobject) {
    /*
    if(flag==1)
      {
        var animationdef = {
    		0: {left: 0}, // transform: transformObject1},
    		100: {left: -350} // transform: transformObject2}
    	};
    	
    	var animDef = kony.ui.createAnimation(animationdef);
    	var animationConfig =    { 
    		duration: 2,
    	    fillMode: kony.anim.FILL_MODE_FORWARDS,
    	    "iterationCount":1
        };
        
        function onAnimStart(){
    						//	alert("animation start!");
    						}
    						
        function onAnimEnd(){
    						  //alert("animation end!");
    						}
        
    	var callBack = {
    							animationStart: onAnimStart,
    							animationEnd: onAnimEnd
    						};
    	
    	Form01.Flex01.animate(animDef, animationConfig, callBack);
        
        flag=0;
        
      }*/
}