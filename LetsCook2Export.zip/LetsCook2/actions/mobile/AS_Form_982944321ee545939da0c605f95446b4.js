function AS_Form_982944321ee545939da0c605f95446b4(eventobject) {
    /*function testfrm_testfrm_onTouchStart_seq0(eventobject, x, y) {
    var getLeft = Form01.Flex01.left;
    var delta1=250;
    var delta=parseInt(delta1);
    var left= parseInt((getLeft.split('dp'))[0]);
    Form01.Flex01.left = left + delta + "dp";
      Form01.forceLayout();
    }
    Form01.Flex02.onTouchMove=testfrm_testfrm_onTouchStart_seq0;*/
}