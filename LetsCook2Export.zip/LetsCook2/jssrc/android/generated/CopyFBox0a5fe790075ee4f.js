function initializeCopyFBox0a5fe790075ee4f() {
    CopyFBox0a5fe790075ee4f = new kony.ui.FlexContainer({
        "clipBounds": false,
        "height": "40dp",
        "id": "CopyFBox0a5fe790075ee4f",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "width": "100%"
    }, {
        "containerWeight": 100
    }, {});
    CopyFBox0a5fe790075ee4f.setDefaultUnit(kony.flex.DP);
    CopyFBox0a5fe790075ee4f.add();
}