function initializeMenuBar() {
    FlexContainer0g831f206ef0542 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "60dp",
        "id": "FlexContainer0g831f206ef0542",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    FlexContainer0g831f206ef0542.setDefaultUnit(kony.flex.DP);
    var Label0f70052d439944c = new kony.ui.Label({
        "centerX": "50%",
        "id": "Label0f70052d439944c",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopydefLabel0c1206df6e71749",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "15dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer0g831f206ef0542.add(Label0f70052d439944c);
}