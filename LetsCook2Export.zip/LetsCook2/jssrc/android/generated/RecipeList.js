function initializeRecipeList() {
    FlexContainer3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "180dp",
        "id": "FlexContainer3",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0a71960000c0d4e"
    }, {}, {});
    FlexContainer3.setDefaultUnit(kony.flex.DP);
    var lblRecipeName = new kony.ui.Label({
        "id": "lblRecipeName",
        "isVisible": true,
        "left": "5dp",
        "skin": "lblSkin",
        "text": "Recipe Name",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "7dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var imgRecipe = new kony.ui.Image2({
        "height": "150dp",
        "id": "imgRecipe",
        "isVisible": true,
        "left": "90dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "32dp",
        "width": "173dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblIngredients = new kony.ui.Label({
        "id": "lblIngredients",
        "isVisible": false,
        "left": "327dp",
        "skin": "lblSkinSmaller",
        "text": "IG",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "7dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblInstructions = new kony.ui.Label({
        "id": "lblInstructions",
        "isVisible": false,
        "left": "327dp",
        "skin": "lblSkinSmaller",
        "text": "IS",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "37dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblTiming = new kony.ui.Label({
        "id": "lblTiming",
        "isVisible": true,
        "left": "317dp",
        "skin": "lblSkin",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "140dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer3.add(lblRecipeName, imgRecipe, lblIngredients, lblInstructions, lblTiming);
}