function addWidgetsfrmConfirm() {
    frmConfirm.setDefaultUnit(kony.flex.DP);
    var Label0a3f3afd0676e44 = new kony.ui.Label({
        "id": "Label0a3f3afd0676e44",
        "isVisible": true,
        "left": "2dp",
        "skin": "LableConfirm",
        "text": "Confirm Ingredients",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "13dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var btnProceed = new kony.ui.Button({
        "focusSkin": "defBtnFocus",
        "height": "50dp",
        "id": "btnProceed",
        "isVisible": true,
        "left": "86dp",
        "onClick": AS_Button_b3c99996892f4acc9ea41816bb3b0ec0,
        "skin": "CopydefBtnNormal0jd490090e77542",
        "text": "Proceed",
        "top": "348dp",
        "width": "203dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    if (typeof initializeFBox0d414679e90cb48 === 'function') initializeFBox0d414679e90cb48();
    var Segment0e5b239a47aae46 = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "data": [{
            "lblIngredient": "Label"
        }, {
            "lblIngredient": "Label"
        }, {
            "lblIngredient": "Label"
        }],
        "groupCells": false,
        "id": "Segment0e5b239a47aae46",
        "isVisible": true,
        "left": "2%",
        "maxHeight": "35%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "Copyseg0d685bb53380745",
        "rowTemplate": FBox0d414679e90cb48,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "90dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "lblIngredient": "lblIngredient"
        },
        "width": "96%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnGoBack = new kony.ui.Button({
        "focusSkin": "defBtnFocus",
        "height": "50dp",
        "id": "btnGoBack",
        "isVisible": true,
        "left": "24dp",
        "onClick": AS_Button_i254a16b37ea44fb807dc27395fe5720,
        "skin": "CopydefBtnNormal0fb99e91bc1654a",
        "text": "Go Back and Edit",
        "top": "445dp",
        "width": "147dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var menubar = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "menubar",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "-80%",
        "skin": "CopyslFbox0f0c294aa54984c",
        "top": "0dp",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    menubar.setDefaultUnit(kony.flex.DP);
    var menusegment = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "Label0f70052d439944c": "Home"
        }, {
            "Label0f70052d439944c": "Saved Recipes"
        }, {
            "Label0f70052d439944c": "Preference"
        }, {
            "Label0f70052d439944c": "Privacy Notice"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "menusegment",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_bc4f06962c7245da8b8334a05eb95d85,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer0g831f206ef0542,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 0,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer0g831f206ef0542": "FlexContainer0g831f206ef0542",
            "Label0f70052d439944c": "Label0f70052d439944c"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    menubar.add(menusegment);
    var btnClear = new kony.ui.Button({
        "focusSkin": "defBtnFocus",
        "height": "50dp",
        "id": "btnClear",
        "isVisible": true,
        "left": "200dp",
        "onClick": AS_Button_ee4a766fd375498ab285d30a1bf17095,
        "skin": "CopydefBtnNormal0jd490090e77542",
        "text": "Clear All",
        "top": "445dp",
        "width": "155dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmConfirm.add(Label0a3f3afd0676e44, btnProceed, Segment0e5b239a47aae46, btnGoBack, menubar, btnClear);
};

function frmConfirmGlobals() {
    frmConfirm = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmConfirm,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer1],
        "id": "frmConfirm",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};