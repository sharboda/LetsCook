function addWidgetsfrmHome() {
    frmHome.setDefaultUnit(kony.flex.DP);
    var TextField1 = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "focusSkin": "defTextBoxFocus",
        "height": "40dp",
        "id": "TextField1",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "2%",
        "onDone": AS_TextField_g83306eb5471400597a108e79ae8e194,
        "placeholder": "rice, pepper, ...",
        "right": "2%",
        "secureTextEntry": false,
        "skin": "CopydefTextBoxNormal0b36aef4db2914c",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "15%",
        "width": "96%",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "placeholderSkin": "defTextBoxPlaceholder",
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var Label2 = new kony.ui.Label({
        "centerX": "50.93%",
        "height": "60dp",
        "id": "Label2",
        "isVisible": true,
        "left": 0,
        "skin": "LableOr",
        "text": "OR",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "28.53%",
        "width": "16.10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Button1 = new kony.ui.Button({
        "centerX": "50.00%",
        "focusSkin": "defBtnFocus",
        "height": "50dp",
        "id": "Button1",
        "isVisible": true,
        "left": "0%",
        "onClick": AS_Button_hded8e0db7ea4234a173bd209bc279b2,
        "skin": "CopydefBtnNormal0dccf763f865d4e",
        "text": "Search",
        "top": "498dp",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0fa785deb74b64b = new kony.ui.Label({
        "id": "Label0fa785deb74b64b",
        "isVisible": true,
        "left": "2%",
        "maxNumberOfLines": 1,
        "skin": "lblSkinSmaller",
        "text": "Enter as many ingredients!",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "22.50%",
        "width": "95.97%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label0hf9afcf3a96b4b = new kony.ui.Label({
        "id": "Label0hf9afcf3a96b4b",
        "isVisible": true,
        "left": "2%",
        "skin": "CopydefLabel0j7a9a615a59e49",
        "text": "Enter Ingredients",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "13dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var FlexContainer0bca6d66e1ebc42 = new kony.ui.FlexContainer({
        "clipBounds": true,
        "height": "220dp",
        "id": "FlexContainer0bca6d66e1ebc42",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "265dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0bca6d66e1ebc42.setDefaultUnit(kony.flex.DP);
    var Camera1 = new kony.ui.Camera({
        "centerX": "49.99%",
        "height": "130dp",
        "id": "Camera1",
        "isVisible": true,
        "left": "0%",
        "onCapture": AS_Camera_a6c056acb46a4d4abcc6d69ecbecb0a0,
        "skin": "CopyslCamera0ae2ba6254dc74a",
        "top": "0.00%",
        "width": "130dp",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "accessMode": constants.CAMERA_IMAGE_ACCESS_MODE_PUBLIC,
        "enableOverlay": false,
        "enablePhotoCropFeature": false
    });
    var Label1 = new kony.ui.Label({
        "centerX": "47.22%",
        "id": "Label1",
        "isVisible": true,
        "left": "0%",
        "skin": "LableScan",
        "text": "Click to Scan your Veggies",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer0bca6d66e1ebc42.add(Camera1, Label1);
    var menubar = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "menubar",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "-80%",
        "onTouchStart": AS_FlexContainer_a56f37b68af641279401c62cd3b45cd5,
        "skin": "CopyslFbox0f0c294aa54984c",
        "top": "0dp",
        "width": "80%",
        "zIndex": 3
    }, {}, {});
    menubar.setDefaultUnit(kony.flex.DP);
    var menusegment = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "Label0f70052d439944c": "Home"
        }, {
            "Label0f70052d439944c": "Saved Recipes"
        }, {
            "Label0f70052d439944c": "Preference"
        }, {
            "Label0f70052d439944c": "Privacy Notice"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "menusegment",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_d27cf0cbbd09463da0918922753d0514,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "Copyseg0h367b033deb342",
        "rowTemplate": FlexContainer0g831f206ef0542,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 10,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer0g831f206ef0542": "FlexContainer0g831f206ef0542",
            "Label0f70052d439944c": "Label0f70052d439944c"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    menubar.add(menusegment);
    var popup = new kony.ui.FlexContainer({
        "centerX": "50%",
        "clipBounds": true,
        "height": "220dp",
        "id": "popup",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "1dp",
        "skin": "slFbox",
        "top": "170dp",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    popup.setDefaultUnit(kony.flex.DP);
    var TextArea0ibe6eb9e2c5144 = new kony.ui.TextArea2({
        "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
        "centerX": "50%",
        "focusSkin": "defTextAreaFocus",
        "height": "120dp",
        "id": "TextArea0ibe6eb9e2c5144",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
        "left": "20dp",
        "numberOfVisibleLines": 3,
        "placeholder": "Placeholder",
        "skin": "CopydefTextAreaNormal0j36259c87ac54c",
        "text": "You can take pictures of veggies to search for related recipes. In this case, the App asks for Camera Permission.",
        "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
        "top": "30dp",
        "width": "90%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [2, 2, 2, 2],
        "paddingInPixel": false
    }, {
        "placeholderSkin": "defTextAreaPlaceholder"
    });
    popup.add(TextArea0ibe6eb9e2c5144);
    frmHome.add(TextField1, Label2, Button1, Label0fa785deb74b64b, Label0hf9afcf3a96b4b, FlexContainer0bca6d66e1ebc42, menubar, popup);
};

function frmHomeGlobals() {
    frmHome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHome,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer1],
        "id": "frmHome",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};