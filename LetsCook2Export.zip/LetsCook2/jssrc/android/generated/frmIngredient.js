function addWidgetsfrmIngredient() {
    frmIngredient.setDefaultUnit(kony.flex.DP);
    var Label1 = new kony.ui.Label({
        "height": "50dp",
        "id": "Label1",
        "isVisible": true,
        "left": "2%",
        "skin": "lblSkinSmaller",
        "text": "Please select the vegetables",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "75dp",
        "width": "96%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var btnConfirm = new kony.ui.Button({
        "focusSkin": "defBtnFocus",
        "height": "50dp",
        "id": "btnConfirm",
        "isVisible": true,
        "left": "29.59%",
        "onClick": AS_Button_i5eedad387324230b85537acafbb23fd,
        "right": "7%",
        "skin": "CopydefBtnNormal0ccc11405918547",
        "text": "Confirm",
        "top": "490dp",
        "width": "40.95%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    if (typeof initializeFBox0j38b5b7fd09f49 === 'function') initializeFBox0j38b5b7fd09f49();
    var segIngredients = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "lblVegName": "Label"
        }, {
            "lblVegName": "Label"
        }, {
            "lblVegName": "Label"
        }],
        "groupCells": false,
        "height": "30%",
        "id": "segIngredients",
        "isVisible": true,
        "left": "2.00%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "Copyseg0f73c5b3c0a5448",
        "rowTemplate": FBox0j38b5b7fd09f49,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_MULTI_SELECT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "120dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "lblVegName": "lblVegName"
        },
        "width": "96%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var tx1 = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "focusSkin": "defTextBoxFocus",
        "height": "40dp",
        "id": "tx1",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "2%",
        "placeholder": "Please enter meat...",
        "secureTextEntry": false,
        "skin": "CopydefTextBoxNormal0da97d75f72fb40",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "368dp",
        "width": "96%",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "placeholderSkin": "defTextBoxPlaceholder",
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var Label0je45af0500474f = new kony.ui.Label({
        "id": "Label0je45af0500474f",
        "isVisible": true,
        "left": "2dp",
        "skin": "CopydefLabel0h90b146bc0df43",
        "text": "Select Ingredients",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "13dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var menubar = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "menubar",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "-80%",
        "onTouchStart": AS_FlexContainer_de2e5bb0b70f49f1a22f37970925a050,
        "skin": "CopyslFbox0f0c294aa54984c",
        "top": "0%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    menubar.setDefaultUnit(kony.flex.DP);
    var menusegment = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "Label0f70052d439944c": "Home"
        }, {
            "Label0f70052d439944c": "Saved Recipes"
        }, {
            "Label0f70052d439944c": "Preference"
        }, {
            "Label0f70052d439944c": "Privacy Notice"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "menusegment",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_a045bf5a46b64c55a6db2b2514ec0b44,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer0g831f206ef0542,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 0,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer0g831f206ef0542": "FlexContainer0g831f206ef0542",
            "Label0f70052d439944c": "Label0f70052d439944c"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    menubar.add(menusegment);
    frmIngredient.add(Label1, btnConfirm, segIngredients, tx1, Label0je45af0500474f, menubar);
};

function frmIngredientGlobals() {
    frmIngredient = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmIngredient,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer1],
        "id": "frmIngredient",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};