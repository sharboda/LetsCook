function addWidgetsfrmPp() {
    frmPp.setDefaultUnit(kony.flex.DP);
    var menubar = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "menubar",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "-80%",
        "skin": "CopyslFbox0f0c294aa54984c",
        "top": "0%",
        "width": "80%",
        "zIndex": 2
    }, {}, {});
    menubar.setDefaultUnit(kony.flex.DP);
    var menusegment = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "Label0f70052d439944c": "Home"
        }, {
            "Label0f70052d439944c": "Saved Recipes"
        }, {
            "Label0f70052d439944c": "Preference"
        }, {
            "Label0f70052d439944c": "Privacy Notice"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "menusegment",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_b95720fcb1034a25b4e6bb444a9eb467,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer0g831f206ef0542,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 0,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer0g831f206ef0542": "FlexContainer0g831f206ef0542",
            "Label0f70052d439944c": "Label0f70052d439944c"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    menubar.add(menusegment);
    var Label0f0b0bcccce9c45 = new kony.ui.Label({
        "id": "Label0f0b0bcccce9c45",
        "isVisible": true,
        "left": "5dp",
        "skin": "CopylblSkinSmaller0jcd1e03d68184e",
        "text": "Privacy Notice",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "16dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var ppText = new kony.ui.RichText({
        "centerX": "50%",
        "height": "620dp",
        "id": "ppText",
        "isVisible": true,
        "left": "0%",
        "linkSkin": "defRichTextLink",
        "skin": "defRichTextNormal",
        "text": "<h1>Welcome to our Privacy Policy</h1>\n<h3>Your privacy is critically important to us.</h3>\n\n\n<p>It is LetsCook’s policy to respect your privacy regarding any information we may collect while operating our website. We have adopted this privacy policy (\"Privacy Policy\") to explain what information may be collected on our Website, how we use this information, and under what circumstances we may disclose the information to third parties. This Privacy Policy applies only to information we collect through the Website and does not apply to our collection of information from other sources.</p>\n\n<h2>Gathering of Personally-Identifying Information</h2>\n<p>We only collect pictured taken by users. We send the pictures to server for ingredient recognition. We make use of the third-party API which is called Clarifai. We won't store the pictures and their recognization results. Except for using Clarifai for recognition, we do not share any user data with third-parties.</p>\n\n<h2>Aggregated Statistics</h2>\n<p>LetsCook allows user to save recipes and set their preferences. Those information will only be stored in user's device. We do not aggregate any of those information.</p>\n\n<h2>Privacy Policy Changes</h2>\n<p>Although most changes are likely to be minor, LetsCook may change its Privacy Policy from time to time, and in LetsCook’s sole discretion. LetsCook encourages visitors to frequently check this page for any changes to its Privacy Policy. Your continued use of this site after any change in this Privacy Policy will constitute your acceptance of such change.</p>\n\n<h2>Clarifai API</h2>\n<p>We use Clarifai API for photo recognition. Clarifai has its own privacy policy at https://www.clarifai.com/privacy.</p>\n\n ",
        "top": "57dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmPp.add(menubar, Label0f0b0bcccce9c45, ppText);
};

function frmPpGlobals() {
    frmPp = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmPp,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer1],
        "id": "frmPp",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};