function addWidgetsfrmSave() {
    frmSave.setDefaultUnit(kony.flex.DP);
    var menubar = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "menubar",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "-80%",
        "skin": "CopyslFbox0f0c294aa54984c",
        "top": "0%",
        "width": "80%",
        "zIndex": 2
    }, {}, {});
    menubar.setDefaultUnit(kony.flex.DP);
    var menusegment = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "Label0f70052d439944c": "Home"
        }, {
            "Label0f70052d439944c": "Saved Recipes"
        }, {
            "Label0f70052d439944c": "Preference"
        }, {
            "Label0f70052d439944c": "Privacy Notice"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "menusegment",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_a8b8ddf9aec547bbb2bec1f1cd6c7269,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer0g831f206ef0542,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 0,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer0g831f206ef0542": "FlexContainer0g831f206ef0542",
            "Label0f70052d439944c": "Label0f70052d439944c"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    menubar.add(menusegment);
    var segementsaved = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "data": [{
            "imgRecipe": "imagedrag.png",
            "lblIngredients": "Label",
            "lblInstructions": "Label",
            "lblRecipeName": "Recipe Name",
            "lblTiming": "Label"
        }, {
            "imgRecipe": "imagedrag.png",
            "lblIngredients": "Label",
            "lblInstructions": "Label",
            "lblRecipeName": "Recipe Name",
            "lblTiming": "Label"
        }, {
            "imgRecipe": "imagedrag.png",
            "lblIngredients": "Label",
            "lblInstructions": "Label",
            "lblRecipeName": "Recipe Name",
            "lblTiming": "Label"
        }],
        "groupCells": false,
        "id": "segementsaved",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_a7826881ef9546fbbef32188106fe039,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer3,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "57dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer3": "FlexContainer3",
            "imgRecipe": "imgRecipe",
            "lblIngredients": "lblIngredients",
            "lblInstructions": "lblInstructions",
            "lblRecipeName": "lblRecipeName",
            "lblTiming": "lblTiming"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSavedRecipes = new kony.ui.Label({
        "id": "lblSavedRecipes",
        "isVisible": true,
        "left": "5dp",
        "skin": "lblSkinSmaller",
        "text": "View saved recipes",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "16dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    frmSave.add(menubar, segementsaved, lblSavedRecipes);
};

function frmSaveGlobals() {
    frmSave = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmSave,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer1],
        "id": "frmSave",
        "init": AS_Form_i56f76de8e8e4f079d996ea1afcfcc56,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_ie703a3ff82d425290d0992a486bd61e,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};