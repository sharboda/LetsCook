//Type your code here
//global variable for the status of each recipe for the user
var isSaved = 0;
//global variable which contains the list of recipes saved by the user
var savedRecipe = [];
//global keyname for savedRecipe
var savedKey = "savedRecipe";

function getCurrentForm() {
    return kony.application.getCurrentForm();
}

function createAnimDef(pos) {
    var animDefinitionOne = {
        "100": {
            "left": pos,
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            }
        }
    };
    animDef = kony.ui.createAnimation(animDefinitionOne);
    return animDef;
}

function createAnimConfig() {
    var config = {
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.5
    };
    return config;
}

function animateOutOfView(menubar) {
    menubar.animate(createAnimDef("-80%"), createAnimConfig(), {
        "animationEnd": function() {}
    });
}

function animateIntoView(menubar) {
    menubar.animate(createAnimDef("0%"), createAnimConfig(), {
        "animationEnd": function() {}
    });
}

function toggleMenuBar() {
    try {
        //alert('in')
        menubar = getCurrentForm().menubar;
        //alert(menubar.left)
        if (menubar.left == "-80%" || menubar.left == "-80.0%") {
            animateIntoView(menubar);
        } else {
            animateOutOfView(menubar);
        }
    } catch (err) {
        alert(err);
    }
}
/**This is the function called when rows of hamburger bar are clicked**/
function onRowClickCallBck(seguiWidget, sectionNumber, rowNumber, selectedState) {
    toggleMenuBar();
    if (rowNumber === 0.0) {
        frmHome.show();
    }
    if (rowNumber === 1.0) {
        frmSave.show();
    }
    if (rowNumber === 2.0) {
        frmCate.show();
    }
    if (rowNumber === 3.0) {
        frmPp.show();
    }
}
/**This is the function called when rows of thr recipe list are clicekd**/
function onListClick(seguiWidget, sectionNumber, rowNumber, selectedState) {
    frmRecipe.show();
}

function checkSaveStatus(recipeName) {
    index = getIndexOfSavedRecipe(recipeName);
    var btn = frmRecipe.buttonSave;
    //check in the local db
    if (index === -1) {
        btn.skin = btnUnSelectedSkin;
        btn.text = "Not Saved";
    } else {
        btn.skin = btnSelectedSkin;
        btn.text = "Saved";
    }
}

function getIndexOfSavedRecipe(recipeName) {
    savedRecipeList = kony.store.getItem(savedKey);
    if (savedRecipeList === null) {
        kony.store.setItem(savedKey, []);
        return -1;
    }
    len = savedRecipeList.length;
    index = -1;
    for (i = 0; i < len; i++) {
        if (savedRecipeList[i][frmRecipe.recipeName.id] === recipeName) {
            index = i;
            break;
        }
    }
    return index;
}

function removeRecipe(savedRecipeList, recipeName) {
    index = getIndexOfSavedRecipe(recipeName);
    if (index === -1) return;
    delete savedRecipeList[index];
    kony.store.setItem(savedKey, savedRecipeList);
}
/**This is the function called when the 'buttonSave' is clicked. The recipe will be saved.**/
/**The tag "isSaved" is created when "onClick" is triggered, which is wrong**/
function toggleSave() {
    try {
        var btn = frmRecipe.buttonSave;
        savedRecipeList = kony.store.getItem(savedKey);
        if (savedRecipeList === null) savedRecipeList = [];
        var recipeN = btn.text;
        //unsaved -> save, store data, change color
        if (btn.skin == btnUnSelectedSkin) {
            recipe = {};
            recipe['lblRecipeName'] = frmRecipe.recipeName.text;
            recipe['lblTiming'] = frmRecipe.fatherTab.lblTiming;
            recipe['lblIngredients'] = frmRecipe.fatherTab.segIngredients.data;
            recipe['lblInstructions'] = frmRecipe.fatherTab.lbIs.text;
            recipe['imgRecipe'] = frmRecipe.fatherTab.imgRecipe.src;
            savedRecipe.push(recipe);
            kony.store.setItem(savedKey, savedRecipe);
            btn.skin = btnSelectedSkin;
            btn.text = "Saved";
            alert("Recipe has been saved");
        } else {
            //save -> unsaved, delete data, change to original color
            //recognize the key from the recipe name
            //delete the related item from local storage
            removeRecipe(savedRecipeList, recipeN);
            //change the color into original one
            btn.skin = btnUnSelectedSkin;
            btn.text = "Not Saved";
            alert("Recipe has been removed from saved");
        }
    } catch (err) {
        alert(err);
    }
}

function parseTextBoxAndShowConfirm() {
    var text = frmHome.TextField1.text;
    var ingredients = text.split(',');
    data = [];
    for (i = 0, len = ingredients.length; i < len; i++) {
        data.push({
            "lblIngredient": ingredients[i].trim()
        });
    }
    frmConfirm.Segment0e5b239a47aae46.setData(data);
    frmConfirm.show();
}
/**This function is called when the "Done" button on "frmCate" is clicked.**/
/**User preferences will be saved to local storage.**/
function savePreference() {
    //one thing to consider is to storing key-value or key only
    //we anyway need to map to different seb-categories
    var mealPre = frmCate.mealCheck.selectedKeyValues;
    var cuisinePre = frmCate.cuisineCheck.selectedKeyValues;
    var dietPre = frmCate.dietCheck.selectedKeyValues;
    if (mealPre !== null) {
        key1 = "meal";
        kony.store.setItem(key1, mealPre);
    }
    if (cuisinePre !== null) {
        key2 = "cuisine";
        kony.store.setItem(key2, cuisinePre);
    }
    if (dietPre !== null) {
        key3 = "diet";
        kony.store.setItem(key3, dietPre);
    }
    //alert(cuisinePre);
    //alert(dietPre);
    frmHome.show();
}

function getSavedRecipes() {
    recipes = kony.store.getItem(savedKey);
    if (recipes === null) {
        frmSave.segementsaved.removeAll();
        frmSave.lblSavedRecipes.text = "You have 0 recipes saved";
    } else {
        frmSave.segementsaved.setData(recipes);
        frmSave.lblSavedRecipes.text = "You have " + recipes.length + " recipes saved";
    }
}

function proceedAndGetRecipes() {
    selectedItems = frmConfirm.Segment0e5b239a47aae46.data;
    ingredients = [];
    for (i = 0; i < selectedItems.length; i++) {
        ingredients.push(selectedItems[i].lblIngredient);
    }
    getRecipes(ingredients);
}

function getRecipes(ingredients) {
    try {
        var request = new kony.net.HttpRequest();
        request.onReadyStateChange = getRecipeCallbackHandler;
        request.open(constants.HTTP_METHOD_POST, "http://sharpi.pythonanywhere.com/recipes", true);
        request.setRequestHeader("Content-Type", "application/json");
        request.send(ingredients);
    } catch (err) {
        alert(err);
    }
}

function getRecipeCallbackHandler() {
    if (this.readyState == constants.HTTP_READY_STATE_DONE) {
        try {
            if (this.response === 'undefined' || this.response === null || this.response === "" || this.response.length === 0) {
                alert("response:" + this.response);
                frmRecipeList.Label0f0b0bcccce9c45.text = "Oops something went wrong. Recheck";
                frmRecipeList.segmentlist.removeAll();
            } else {
                frmRecipeList.Label0f0b0bcccce9c45.text = "Please choose Recipe!!";
                frmRecipeList.segmentlist.setData(this.response);
            }
            frmRecipeList.show();
        } catch (err) {
            alert(err);
        }
        kony.application.dismissLoadingScreen();
    }
}

function navigateOnSelected(item) {
    try {
        frmRecipe.fatherTab.lbIs.text = item.lblInstructions;
        frmRecipe.fatherTab.imgRecipe.src = item.imgRecipe;
        frmRecipe.recipeName.text = item.lblRecipeName;
        frmRecipe.fatherTab.lblTiming = item.lblTiming;
        dict = [];
        var list = eval(item.lblIngredients);
        for (i = 0; i < list.length; i++) {
            element = {};
            element.lblVegName = list[i];
            dict.push(element);
        }
        frmRecipe.fatherTab.segIngredients.setData(dict);
        checkSaveStatus(item.lblRecipeName);
        frmRecipe.show();
    } catch (ex) {
        alert(ex);
    }
}

function onCapture(cameraObject) {
    alert('in');
    var rawbytes = cameraObject.rawBytes;
    var base64 = kony.convertToBase64(rawbytes);
    try {
        var request = new kony.net.HttpRequest();
        request.onReadyStateChange = onCaptureCallBackHandler;
        request.open(constants.HTTP_METHOD_POST, "http://sharpi.pythonanywhere.com/veggies", true);
        request.setRequestHeader("Content-Type", "application/json");
        request.send(base64);
    } catch (err) {
        alert(err);
    }
}

function onCaptureCallBackHandler() {
    if (this.readyState == constants.HTTP_READY_STATE_DONE) {
        try {
            if (this.response === 'undefined' || this.response === null || this.response === "" || this.response.length === 0) {
                alert("OOps, something went wrong. Please try again");
                return;
            } else {}
            data = fromListToDict(this.response);
            frmIngredient.segIngredients.setData(data);
            frmIngredient.show();
            s = frmIngredient.segIngredients.data;
        } catch (err) {
            alert(err);
        }
    }
}

function fromListToDict(list) {
    dict = [];
    for (i = 0; i < list.length; i++) {
        element = {};
        element.lblVegName = list[i];
        dict.push(element);
    }
    return dict;
}

function onSelectingIngFromCamera() {
    kony.application.showLoadingScreen(null, "Processing ... Please Wait .....", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, {});
    selectedItems = frmIngredient.segIngredients.selectedRowItems();
    alert(selectedItems);
    otherItems = frmIngredient.tx1.text;
    if (otherItems !== null) {
        otherItems = otherItems.split(',');
        selectedItems.append(otherItems);
    }
    if (selectedItems.length < 1) {
        alert("Please enter at least one ingredient");
    }
    getRecipes(selectedItems);
}
/**Thiis fuction is clalled when "freshBtn" is clicked.
The textbox in 'frmHome' and ingredients lists in either from
are supposed to be cleared**/
function onClickRefresh() {
    //navigate to the home page
    frmHome.show();
    //frmHome.TextField1
}