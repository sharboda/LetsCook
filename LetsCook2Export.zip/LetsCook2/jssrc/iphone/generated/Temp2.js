function initializeTemp2() {
    FlexContainer2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "50dp",
        "id": "FlexContainer2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    FlexContainer2.setDefaultUnit(kony.flex.DP);
    var Label1 = new kony.ui.Label({
        "height": "100%",
        "id": "Label1",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopydefLabel0b736d0365cd548",
        "text": "Label",
        "textStyle": {},
        "top": "0dp",
        "width": "80%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var FlexContainer3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "FlexContainer3",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "90%",
        "skin": "CopyslFbox0a7104c4b2b2c46",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {}, {});
    FlexContainer3.setDefaultUnit(kony.flex.DP);
    FlexContainer3.add();
    FlexContainer2.add(Label1, FlexContainer3);
}