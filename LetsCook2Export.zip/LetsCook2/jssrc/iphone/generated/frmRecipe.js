function addWidgetsfrmRecipe() {
    frmRecipe.setDefaultUnit(kony.flex.DP);
    var fatherTab = new kony.ui.TabPane({
        "activeSkin": "tabCanvas",
        "activeTabs": [0],
        "height": "80%",
        "id": "fatherTab",
        "inactiveSkin": "CopytabCanvasInactive0d11bc9eb5d8d4a",
        "isVisible": true,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "left": "0dp",
        "top": "10.89%",
        "viewConfig": {
            "collapsibleViewConfig": {
                "imagePosition": constants.TABPANE_COLLAPSIBLE_IMAGE_POSITION_RIGHT,
                "imageposition": "right",
                "tabNameAlignment": constants.TABPANE_COLLAPSIBLE_TABNAME_ALIGNMENT_LEFT,
                "tabnamealignment": "left",
                "toggleTabs": false,
                "toggletabs": false
            },
            "collapsibleviewconfig": {
                "imagePosition": constants.TABPANE_COLLAPSIBLE_IMAGE_POSITION_RIGHT,
                "imageposition": "right",
                "tabNameAlignment": constants.TABPANE_COLLAPSIBLE_TABNAME_ALIGNMENT_LEFT,
                "tabnamealignment": "left",
                "toggleTabs": false,
                "toggletabs": false
            },
            "pageViewConfig": {
                "needPageIndicator": true
            },
            "tabViewConfig": {
                "headerPosition": constants.TAB_HEADER_POSITION_TOP,
                "image1": "tableftarrow.png",
                "image2": "tabrightarrow.png"
            },
        },
        "viewType": constants.TABPANE_VIEW_TYPE_PAGEVIEW,
        "width": "100%",
        "zIndex": 1
    }, {
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
        "showProgressIndicator": false
    });
    var About = new kony.ui.FlexContainer({
        "clipBounds": true,
        "height": "400dp",
        "id": "About",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "orientation": constants.BOX_LAYOUT_VERTICAL,
        "skin": "slTab",
        "tabName": "About",
        "width": "100%"
    }, {
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    About.setDefaultUnit(kony.flex.DP);
    var imgRecipe = new kony.ui.Image2({
        "centerX": "50.04%",
        "centerY": "55%",
        "height": "300dp",
        "id": "imgRecipe",
        "isVisible": true,
        "left": "46dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "60dp",
        "width": "300dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblBar = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "41dp",
        "id": "lblBar",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "29dp",
        "width": "100.06%",
        "zIndex": 2
    }, {}, {});
    lblBar.setDefaultUnit(kony.flex.DP);
    var lblTiming1212 = new kony.ui.Label({
        "id": "lblTiming1212",
        "isVisible": true,
        "left": "5dp",
        "skin": "onShow",
        "text": "About",
        "textStyle": {},
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblIgasdfasd = new kony.ui.Label({
        "id": "lblIgasdfasd",
        "isVisible": true,
        "left": "5dp",
        "skin": "notOnShow",
        "text": "Ingredients",
        "textStyle": {},
        "top": "0dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblIsasdfasdf = new kony.ui.Label({
        "id": "lblIsasdfasdf",
        "isVisible": true,
        "left": "5dp",
        "skin": "notOnShow",
        "text": "Instructions",
        "textStyle": {},
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    lblBar.add(lblTiming1212, lblIgasdfasd, lblIsasdfasdf);
    About.add(imgRecipe, lblBar);
    fatherTab.addTab("About", "About", null, About, null);
    var Ingredients = new kony.ui.FlexContainer({
        "clipBounds": true,
        "height": "400dp",
        "id": "Ingredients",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "orientation": constants.BOX_LAYOUT_VERTICAL,
        "skin": "slTab",
        "tabName": "Ingredients",
        "width": "100%"
    }, {
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    Ingredients.setDefaultUnit(kony.flex.DP);
    var CopylblBar0c8f73132294e4d = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "41dp",
        "id": "CopylblBar0c8f73132294e4d",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "29dp",
        "width": "100.06%",
        "zIndex": 2
    }, {}, {});
    CopylblBar0c8f73132294e4d.setDefaultUnit(kony.flex.DP);
    var CopylblTiming0f8b4303baa9e4b = new kony.ui.Label({
        "id": "CopylblTiming0f8b4303baa9e4b",
        "isVisible": true,
        "left": "5dp",
        "skin": "notOnShow",
        "text": "About",
        "textStyle": {},
        "top": "0dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopylblIg0c9136cace16f46 = new kony.ui.Label({
        "id": "CopylblIg0c9136cace16f46",
        "isVisible": true,
        "left": "5dp",
        "skin": "onShow",
        "text": "Ingredients",
        "textStyle": {},
        "top": "0dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopylblIs0fe131b9be08f4f = new kony.ui.Label({
        "id": "CopylblIs0fe131b9be08f4f",
        "isVisible": true,
        "left": "5dp",
        "skin": "notOnShow",
        "text": "Instructions",
        "textStyle": {},
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    CopylblBar0c8f73132294e4d.add(CopylblTiming0f8b4303baa9e4b, CopylblIg0c9136cace16f46, CopylblIs0fe131b9be08f4f);
    var FlexScrollContainer0afafccb1f9af47 = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": false,
        "allowVerticalBounce": true,
        "bounces": true,
        "clipBounds": true,
        "enableScrolling": true,
        "height": "220dp",
        "horizontalScrollIndicator": true,
        "id": "FlexScrollContainer0afafccb1f9af47",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": "80dp",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 2
    }, {}, {});
    FlexScrollContainer0afafccb1f9af47.setDefaultUnit(kony.flex.DP);
    if (typeof initializeCopyFBox0b74faf74c1964d === 'function') initializeCopyFBox0b74faf74c1964d();
    var segIngredients = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "data": [{
            "lblVegName": "Label"
        }, {
            "lblVegName": "Label"
        }, {
            "lblVegName": "Label"
        }],
        "groupCells": false,
        "id": "segIngredients",
        "isVisible": true,
        "left": "2.00%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "Copyseg0f73c5b3c0a5448",
        "rowTemplate": CopyFBox0b74faf74c1964d,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "5dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "lblVegName": "lblVegName"
        },
        "width": "96%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": true,
        "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
        "enableDictionary": false,
        "indicator": constants.SEGUI_ROW_SELECT,
        "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
        "showProgressIndicator": true
    });
    FlexScrollContainer0afafccb1f9af47.add(segIngredients);
    Ingredients.add(CopylblBar0c8f73132294e4d, FlexScrollContainer0afafccb1f9af47);
    fatherTab.addTab("Ingredients", "Ingredients", null, Ingredients, null);
    var Directions = new kony.ui.FlexContainer({
        "clipBounds": true,
        "height": "400dp",
        "id": "Directions",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "orientation": constants.BOX_LAYOUT_VERTICAL,
        "skin": "slTab",
        "tabName": "Directions",
        "width": "100%"
    }, {
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    Directions.setDefaultUnit(kony.flex.DP);
    var CopylblBar0c118fdd9248549 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "41dp",
        "id": "CopylblBar0c118fdd9248549",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "29dp",
        "width": "100.06%",
        "zIndex": 2
    }, {}, {});
    CopylblBar0c118fdd9248549.setDefaultUnit(kony.flex.DP);
    var CopylblTiming0b10d81548a2c4d = new kony.ui.Label({
        "id": "CopylblTiming0b10d81548a2c4d",
        "isVisible": true,
        "left": "5dp",
        "skin": "notOnShow",
        "text": "About",
        "textStyle": {},
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopylblIg0aa230b675c5645 = new kony.ui.Label({
        "id": "CopylblIg0aa230b675c5645",
        "isVisible": true,
        "left": "5dp",
        "skin": "notOnShow",
        "text": "Ingredients",
        "textStyle": {},
        "top": "0dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopylblIs0i2691a6f3b1d4c = new kony.ui.Label({
        "id": "CopylblIs0i2691a6f3b1d4c",
        "isVisible": true,
        "left": "5dp",
        "skin": "onShow",
        "text": "Instructions",
        "textStyle": {},
        "top": "0",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    CopylblBar0c118fdd9248549.add(CopylblTiming0b10d81548a2c4d, CopylblIg0aa230b675c5645, CopylblIs0i2691a6f3b1d4c);
    var FlexScrollContainer0dd348158eb9c44 = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": false,
        "allowVerticalBounce": true,
        "bounces": true,
        "clipBounds": true,
        "enableScrolling": true,
        "height": "100%",
        "horizontalScrollIndicator": true,
        "id": "FlexScrollContainer0dd348158eb9c44",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": "80dp",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexScrollContainer0dd348158eb9c44.setDefaultUnit(kony.flex.DP);
    var lbIs = new kony.ui.Label({
        "id": "lbIs",
        "isVisible": true,
        "left": "11dp",
        "skin": "defLabel",
        "text": "Directions",
        "textStyle": {},
        "top": "15dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    FlexScrollContainer0dd348158eb9c44.add(lbIs);
    Directions.add(CopylblBar0c118fdd9248549, FlexScrollContainer0dd348158eb9c44);
    fatherTab.addTab("Directions", "Directions", null, Directions, null);
    var recipeName = new kony.ui.Label({
        "id": "recipeName",
        "isVisible": true,
        "left": "11dp",
        "maxWidth": "65%",
        "skin": "CopydefLabel0c4387fbef72d40",
        "text": "Label",
        "textStyle": {},
        "top": "15dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var menubar = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "menubar",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "-80%",
        "skin": "CopyslFbox0f0c294aa54984c",
        "top": "0%",
        "width": "80%",
        "zIndex": 2
    }, {}, {});
    menubar.setDefaultUnit(kony.flex.DP);
    var menusegment = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "Label0f70052d439944c": "Home"
        }, {
            "Label0f70052d439944c": "Saved Recipes"
        }, {
            "Label0f70052d439944c": "Preference"
        }, {
            "Label0f70052d439944c": "Privacy Notice"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "menusegment",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_a4262d7b4f004e0f8fc61f7079f1abae,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer0g831f206ef0542,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 0,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer0g831f206ef0542": "FlexContainer0g831f206ef0542",
            "Label0f70052d439944c": "Label0f70052d439944c"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": true,
        "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
        "enableDictionary": false,
        "indicator": constants.SEGUI_ROW_SELECT,
        "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
        "showProgressIndicator": true
    });
    menubar.add(menusegment);
    var buttonSave = new kony.ui.Button({
        "focusSkin": "defBtnFocus",
        "height": "56dp",
        "id": "buttonSave",
        "isVisible": true,
        "left": "305dp",
        "onClick": AS_Button_j4bb5fba7341464eb99191c36f6f4847,
        "skin": "CopydefBtnNormal0ffb4fcbed2db48",
        "text": "Save",
        "top": "4dp",
        "width": "60dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    frmRecipe.add(fatherTab, recipeName, menubar, buttonSave);
};

function frmRecipeGlobals() {
    frmRecipe = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmRecipe,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer1],
        "id": "frmRecipe",
        "init": AS_Form_a4b38e34c0834a708a4d11d5a4090e1b,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_e09fd721a66c4533b0ddb3c32a788c0e,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
};