function initializeCopyFBox0abaac395c34d41() {
    CopyFBox0abaac395c34d41 = new kony.ui.FlexContainer({
        "clipBounds": false,
        "enableCache": false,
        "height": "40dp",
        "id": "CopyFBox0abaac395c34d41",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "width": "100%"
    }, {
        "containerWeight": 100
    }, {});
    CopyFBox0abaac395c34d41.setDefaultUnit(kony.flex.DP);
    CopyFBox0abaac395c34d41.add();
}