function initializeFBox0j38b5b7fd09f49() {
    FBox0j38b5b7fd09f49 = new kony.ui.FlexContainer({
        "clipBounds": false,
        "enableCache": false,
        "height": "40dp",
        "id": "FBox0j38b5b7fd09f49",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "width": "100%"
    }, {
        "containerWeight": 100
    }, {});
    FBox0j38b5b7fd09f49.setDefaultUnit(kony.flex.DP);
    var lblVegName = new kony.ui.Label({
        "enableCache": false,
        "id": "lblVegName",
        "isVisible": true,
        "left": "21dp",
        "skin": "lblSkin",
        "text": "Label",
        "textStyle": {},
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    FBox0j38b5b7fd09f49.add(lblVegName);
}