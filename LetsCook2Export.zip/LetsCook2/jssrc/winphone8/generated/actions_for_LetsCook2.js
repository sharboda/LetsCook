//actions.js file 
function AS_Button_a5584b7ba6974fb6b0d3ca04d272ebb8(eventobject) {
    return toggleMenuBar.call(this);
}

function AS_Button_b3c99996892f4acc9ea41816bb3b0ec0(eventobject) {
    return proceedAndGetRecipes.call(this);
}

function AS_Button_d087a749a9834c3c84fff82602b01331(eventobject) {
    frmHome.show();
}

function AS_Button_ee4a766fd375498ab285d30a1bf17095(eventobject) {
    frmConfirm.Segment0e5b239a47aae46.removeAll();
}

function AS_Button_fde280f37e5d4363b4c695587f5ead24(eventobject) {
    return savePreference.call(this);
}

function AS_Button_haeb663aba8148c1adff9f7aca807ec5(eventobject) {
    return toggleMenuBar.call(this);
}

function AS_Button_hded8e0db7ea4234a173bd209bc279b2(eventobject) {
    return parseTextBoxAndShowConfirm.call(this);
}

function AS_Button_i254a16b37ea44fb807dc27395fe5720(eventobject) {
    frmHome.show();
}

function AS_Button_i5eedad387324230b85537acafbb23fd(eventobject) {
    frmRecipeList.show();
}

function AS_Button_i902affb71c84580801d9ca663a7f01e(eventobject) {
    frmHome.show();
}

function AS_Button_j4bb5fba7341464eb99191c36f6f4847(eventobject) {
    return toggleSave.call(this);
}

function AS_Button_jd173020fac449bb9d2462b927ee7d96(eventobject) {
    frmHome.show();
}

function AS_FlexContainer_a56f37b68af641279401c62cd3b45cd5(eventobject, x, y) {}

function AS_FlexContainer_a85b2c39c4d34027ba4a1c7f83b442cd(eventobject) {}

function AS_FlexContainer_bf22e8af1b3f42faa02dbeb3792185b0(eventobject, x, y) {}

function AS_FlexContainer_c25c035cbc23488bbe034e15ea4b609d(eventobject) {}

function AS_FlexContainer_d067f049292047199d87aa3b37dd6775(eventobject, x, y) {}

function AS_FlexContainer_de2e5bb0b70f49f1a22f37970925a050(eventobject, x, y) {}

function AS_FlexContainer_e0907c27fbec42c4a73ca37d6f8acf41(eventobject, x, y) {}

function AS_FlexContainer_eee9bfcab5144a63b0880db0572e4782(eventobject, x, y) {}

function AS_FlexContainer_f6a569aa59ae4a24b8cc9fad80f0eb10(eventobject, x, y) {}

function AS_FlexContainer_id8f107570854001b494f89eb8e0b25e(eventobject, x, y) {}

function AS_Form_a4b38e34c0834a708a4d11d5a4090e1b(eventobject) {}

function AS_Form_ie703a3ff82d425290d0992a486bd61e(eventobject) {
    return getSavedRecipes.call(this);
}

function AS_Segment_a045bf5a46b64c55a6db2b2514ec0b44(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_a4262d7b4f004e0f8fc61f7079f1abae(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_a7826881ef9546fbbef32188106fe039(eventobject, sectionNumber, rowNumber) {
    return navigateOnSelected.call(this, frmSave.segmentsaved.selectedItems[0]);
}

function AS_Segment_a8b8ddf9aec547bbb2bec1f1cd6c7269(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_ab2c198f1fa244a390349eecdaf8800c(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_acffd927ed8642d09f98fa1f9aedacd3(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_b408632c91eb4e0b98042f78cd12497f(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_b95720fcb1034a25b4e6bb444a9eb467(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_bc4f06962c7245da8b8334a05eb95d85(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_d27cf0cbbd09463da0918922753d0514(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_d67f09102d8f4b7db587e3276235528b(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_e053daa978ae449b8bc32131270294fa(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_e8f4497072f340a4a9939a283393fdca(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_ed404ee4049948319319255153748d8e(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_gdbd74a4ed6545eab88fcc7af14d31aa(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_Segment_ia370ff3a2a94a5aa14148be2fb18cd7(eventobject, sectionNumber, rowNumber) {
    return navigateOnSelected.call(this, frmRecipeList.segmentlist.selectedItems[0]);
}

function AS_Segment_jdecfb29891648eea814fe56a58ffc79(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}

function AS_TextField_g83306eb5471400597a108e79ae8e194(eventobject, changedtext) {
    return parseTextBoxAndShowConfirm.call(this);
}

function AS_Camera_a6c056acb46a4d4abcc6d69ecbecb0a0(eventobject) {
    return onCapture.call(this, eventobject);
}

function AS_Form_e09fd721a66c4533b0ddb3c32a788c0e(eventobject) {}

function AS_Form_i56f76de8e8e4f079d996ea1afcfcc56(eventobject) {}