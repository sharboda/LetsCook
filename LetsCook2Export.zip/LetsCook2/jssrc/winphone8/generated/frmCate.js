function addWidgetsfrmCate() {
    frmCate.setDefaultUnit(kony.flex.DP);
    var menubar = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "100%",
        "id": "menubar",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "-80%",
        "skin": "slFbox",
        "top": "0%",
        "width": "80%",
        "zIndex": 2
    }, {}, {});
    menubar.setDefaultUnit(kony.flex.DP);
    var menusegment = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "Label0f70052d439944c": "Home"
        }, {
            "Label0f70052d439944c": "Saved Recipes"
        }, {
            "Label0f70052d439944c": "Preference"
        }, {
            "Label0f70052d439944c": "Privacy Notice"
        }],
        "enableCache": false,
        "groupCells": false,
        "height": "100%",
        "id": "menusegment",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_e8f4497072f340a4a9939a283393fdca,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer0g831f206ef0542,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "aaaaaa00",
        "separatorRequired": true,
        "separatorThickness": 0,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer0g831f206ef0542": "FlexContainer0g831f206ef0542",
            "Label0f70052d439944c": "Label0f70052d439944c"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    menubar.add(menusegment);
    var Label0f0b0bcccce9c45 = new kony.ui.Label({
        "enableCache": false,
        "id": "Label0f0b0bcccce9c45",
        "isVisible": true,
        "left": "5dp",
        "skin": "lblMedium",
        "text": "Choose your preferences",
        "textStyle": {},
        "top": "16dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var mealContainer = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "enableCache": false,
        "height": "155dp",
        "id": "mealContainer",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "50dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    mealContainer.setDefaultUnit(kony.flex.DP);
    var Label0c9bd5df09d0341 = new kony.ui.Label({
        "enableCache": false,
        "id": "Label0c9bd5df09d0341",
        "isVisible": true,
        "left": "4dp",
        "skin": "CopydefLabel0hcf431c4efa747",
        "text": "Meal Type",
        "textStyle": {},
        "top": "6dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var mealCheck = new kony.ui.CheckBoxGroup({
        "enableCache": false,
        "height": "120dp",
        "id": "mealCheck",
        "isVisible": true,
        "left": "4dp",
        "masterData": [
            ["cbg1", "Breakfast & Brunch"],
            ["cbg2", "Dinner"],
            ["cbg3", "Desserts"]
        ],
        "selectedKeyValues": [
            ["cbg1", "Breakfast & Brunch"],
            ["cbg2", "Dinner"]
        ],
        "selectedKeys": ["cbg1", "cbg2"],
        "skin": "CopyslCheckBoxGroup0i097f8b457f349",
        "top": "30dp",
        "width": "97.78%",
        "zIndex": 1
    }, {
        "itemOrientation": constants.CHECKBOX_ITEM_ORIENTATION_VERTICAL,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    mealContainer.add(Label0c9bd5df09d0341, mealCheck);
    var worldContainer = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "enableCache": false,
        "height": "155dp",
        "id": "worldContainer",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "205dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    worldContainer.setDefaultUnit(kony.flex.DP);
    var CopyLabel0bb1db237c6664e = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0bb1db237c6664e",
        "isVisible": true,
        "left": "4dp",
        "skin": "CopydefLabel0hcf431c4efa747",
        "text": "World Cuisine",
        "textStyle": {},
        "top": "6dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var cuisineCheck = new kony.ui.CheckBoxGroup({
        "enableCache": false,
        "height": "120dp",
        "id": "cuisineCheck",
        "isVisible": true,
        "left": "4dp",
        "masterData": [
            ["cbg1", "Asia"],
            ["cbg2", "Indian"],
            ["cbg3", "Italian"]
        ],
        "skin": "CopyslCheckBoxGroup0i097f8b457f349",
        "top": "30dp",
        "width": "97.78%",
        "zIndex": 1
    }, {
        "itemOrientation": constants.CHECKBOX_ITEM_ORIENTATION_VERTICAL,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    worldContainer.add(CopyLabel0bb1db237c6664e, cuisineCheck);
    var healthConatiner = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "enableCache": false,
        "height": "155dp",
        "id": "healthConatiner",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "360dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    healthConatiner.setDefaultUnit(kony.flex.DP);
    var CopyLabel0h34c44c88ff040 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0h34c44c88ff040",
        "isVisible": true,
        "left": "4dp",
        "skin": "CopydefLabel0hcf431c4efa747",
        "text": "Health & Diet",
        "textStyle": {},
        "top": "6dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var dietCheck = new kony.ui.CheckBoxGroup({
        "enableCache": false,
        "height": "120dp",
        "id": "dietCheck",
        "isVisible": true,
        "left": "4dp",
        "masterData": [
            ["cbg1", "Gluten Free"],
            ["cbg2", "Low Fat"],
            ["cbg3", "Low Calorie"]
        ],
        "skin": "CopyslCheckBoxGroup0i097f8b457f349",
        "top": "30dp",
        "width": "97.78%",
        "zIndex": 1
    }, {
        "itemOrientation": constants.CHECKBOX_ITEM_ORIENTATION_VERTICAL,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    healthConatiner.add(CopyLabel0h34c44c88ff040, dietCheck);
    var skipBtn = new kony.ui.Button({
        "enableCache": false,
        "focusSkin": "defBtnFocus",
        "height": "25dp",
        "id": "skipBtn",
        "isVisible": true,
        "left": "285dp",
        "onClick": AS_Button_jd173020fac449bb9d2462b927ee7d96,
        "skin": "CopydefBtnNormal0accb8c082d7742",
        "text": "skip",
        "top": "19dp",
        "width": "80dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var doneBtn = new kony.ui.Button({
        "centerX": "50%",
        "enableCache": false,
        "focusSkin": "defBtnFocus",
        "height": "50dp",
        "id": "doneBtn",
        "isVisible": true,
        "left": "58dp",
        "onClick": AS_Button_fde280f37e5d4363b4c695587f5ead24,
        "skin": "CopydefBtnNormal0f1095fa08ccd4b",
        "text": "Done",
        "top": "520dp",
        "width": "150dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmCate.add(menubar, Label0f0b0bcccce9c45, mealContainer, worldContainer, healthConatiner, skipBtn, doneBtn);
};

function frmCateGlobals() {
    frmCate = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmCate,
        "enableCache": false,
        "enabledForIdleTimeout": false,
        "headers": [FlexContainer1],
        "id": "frmCate",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "animateHeaderFooter": false,
        "directChildrenIDs": ["CopyLabel0bb1db237c6664e", "CopyLabel0h34c44c88ff040", "cuisineCheck", "dietCheck", "doneBtn", "healthConatiner", "Label0c9bd5df09d0341", "Label0f0b0bcccce9c45", "mealCheck", "mealContainer", "menubar", "menusegment", "skipBtn", "worldContainer"],
        "retainScrollPosition": false,
        "titleBar": true
    });
};