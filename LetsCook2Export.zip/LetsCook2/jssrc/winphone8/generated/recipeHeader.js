function initializerecipeHeader() {
    FlexContainer1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "50dp",
        "id": "FlexContainer1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0bcbd857bef3142"
    }, {}, {});
    FlexContainer1.setDefaultUnit(kony.flex.DP);
    var FlexContainer2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "36dp",
        "id": "FlexContainer2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "7dp",
        "onClick": AS_FlexContainer_a85b2c39c4d34027ba4a1c7f83b442cd,
        "onTouchEnd": AS_FlexContainer_bf22e8af1b3f42faa02dbeb3792185b0,
        "onTouchMove": AS_FlexContainer_e0907c27fbec42c4a73ca37d6f8acf41,
        "onTouchStart": AS_FlexContainer_id8f107570854001b494f89eb8e0b25e,
        "skin": "CopyslFbox0a09af871d3a947",
        "top": "7dp",
        "width": "8.26%",
        "zIndex": 1
    }, {}, {});
    FlexContainer2.setDefaultUnit(kony.flex.DP);
    var Button0a4b93efa4ada42 = new kony.ui.Button({
        "enableCache": false,
        "focusSkin": "defBtnFocus",
        "height": "100%",
        "id": "Button0a4b93efa4ada42",
        "isVisible": true,
        "left": "0dp",
        "onClick": AS_Button_a5584b7ba6974fb6b0d3ca04d272ebb8,
        "skin": "CopydefBtnNormal0bfc1084a36ee49",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer2.add(Button0a4b93efa4ada42);
    var Label1 = new kony.ui.Label({
        "enableCache": false,
        "height": "50dp",
        "id": "Label1",
        "isVisible": true,
        "left": "0%",
        "skin": "headerLbl",
        "text": "Get a Recipe",
        "textStyle": {},
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer1.add(FlexContainer2, Label1);
}