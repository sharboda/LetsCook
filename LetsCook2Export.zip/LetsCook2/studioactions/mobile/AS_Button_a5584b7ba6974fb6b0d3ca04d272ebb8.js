function AS_Button_a5584b7ba6974fb6b0d3ca04d272ebb8(eventobject) {
    return toggleMenuBar.call(this);
}