function AS_Button_b3c99996892f4acc9ea41816bb3b0ec0(eventobject) {
    return proceedAndGetRecipes.call(this);
}