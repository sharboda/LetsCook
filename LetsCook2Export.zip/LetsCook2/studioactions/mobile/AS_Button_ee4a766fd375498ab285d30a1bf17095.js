function AS_Button_ee4a766fd375498ab285d30a1bf17095(eventobject) {
    frmConfirm.Segment0e5b239a47aae46.removeAll();
}