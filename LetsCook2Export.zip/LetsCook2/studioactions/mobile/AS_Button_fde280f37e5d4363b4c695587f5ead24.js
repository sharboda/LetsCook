function AS_Button_fde280f37e5d4363b4c695587f5ead24(eventobject) {
    return savePreference.call(this);
}