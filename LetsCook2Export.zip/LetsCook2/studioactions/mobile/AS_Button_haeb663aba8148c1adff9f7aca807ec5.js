function AS_Button_haeb663aba8148c1adff9f7aca807ec5(eventobject) {
    return toggleMenuBar.call(this);
}