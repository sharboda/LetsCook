function AS_Button_hded8e0db7ea4234a173bd209bc279b2(eventobject) {
    return parseTextBoxAndShowConfirm.call(this);
}