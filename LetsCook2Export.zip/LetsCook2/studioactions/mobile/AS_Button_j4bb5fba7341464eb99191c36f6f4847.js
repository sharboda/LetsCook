function AS_Button_j4bb5fba7341464eb99191c36f6f4847(eventobject) {
    return toggleSave.call(this);
}