function AS_Camera_a6c056acb46a4d4abcc6d69ecbecb0a0(eventobject) {
    return onCapture.call(this, eventobject);
}