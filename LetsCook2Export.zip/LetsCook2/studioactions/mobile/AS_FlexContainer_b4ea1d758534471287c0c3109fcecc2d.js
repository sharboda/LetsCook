function AS_FlexContainer_b4ea1d758534471287c0c3109fcecc2d(eventobject) {
    return toggleMenuBar.call(this);
}