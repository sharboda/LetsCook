function AS_FlexContainer_b9cbfed4a66543c4aa9041b4130b045b(eventobject) {
    return toggleMenuBar.call(this);
}