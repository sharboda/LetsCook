function AS_FlexContainer_c1444c6ad0ea4afe9a883dc5d62c4402(eventobject) {
    return toggleMenuBar.call(this);
}