function AS_FlexContainer_c8b08c6d369b4adcac9ee50155bd74c8(eventobject) {
    return toggleMenuBar.call(this);
}