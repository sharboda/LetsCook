function AS_FlexContainer_f5e08002440d417c948aff71a2a8c478(eventobject) {
    return toggleMenuBar.call(this);
}