function AS_FlexContainer_g4b8fbfa8b224cd7ba4d353232001bf9(eventobject) {
    return toggleMenuBar.call(this);
}