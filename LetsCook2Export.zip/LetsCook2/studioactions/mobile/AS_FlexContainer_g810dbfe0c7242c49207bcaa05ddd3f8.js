function AS_FlexContainer_g810dbfe0c7242c49207bcaa05ddd3f8(eventobject) {
    return toggleMenuBar.call(this);
}