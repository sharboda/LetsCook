function AS_FlexContainer_g87f8993ada646d4a932bc4b325f32aa(eventobject) {
    return toggleMenuBar.call(this);
}