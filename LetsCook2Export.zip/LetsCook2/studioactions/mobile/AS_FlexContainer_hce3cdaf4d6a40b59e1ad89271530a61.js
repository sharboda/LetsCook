function AS_FlexContainer_hce3cdaf4d6a40b59e1ad89271530a61(eventobject) {
    return toggleMenuBar.call(this);
}