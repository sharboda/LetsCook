function AS_FlexContainer_i2a6e50c0a684a24b47c70560f1c36aa(eventobject) {
    return toggleMenuBar.call(this);
}