function AS_Segment_a045bf5a46b64c55a6db2b2514ec0b44(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}