function AS_Segment_a13f88fe79824658a0cb05772ccc4b1a(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}