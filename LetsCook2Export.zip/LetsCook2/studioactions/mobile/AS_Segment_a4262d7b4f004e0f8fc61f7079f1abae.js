function AS_Segment_a4262d7b4f004e0f8fc61f7079f1abae(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}