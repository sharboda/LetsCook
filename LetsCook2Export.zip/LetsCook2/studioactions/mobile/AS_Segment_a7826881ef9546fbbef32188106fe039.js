function AS_Segment_a7826881ef9546fbbef32188106fe039(eventobject, sectionNumber, rowNumber) {
    return navigateOnSelected.call(this, frmSave.segmentsaved.selectedItems[0]);
}