function AS_Segment_a8b8ddf9aec547bbb2bec1f1cd6c7269(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}