function AS_Segment_aa274b2f765042bab9b88c642f7f9e73(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}