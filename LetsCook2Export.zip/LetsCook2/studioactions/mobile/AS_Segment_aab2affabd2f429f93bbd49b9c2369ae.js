function AS_Segment_aab2affabd2f429f93bbd49b9c2369ae(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}