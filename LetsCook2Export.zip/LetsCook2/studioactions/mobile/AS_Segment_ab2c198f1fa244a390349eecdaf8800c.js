function AS_Segment_ab2c198f1fa244a390349eecdaf8800c(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}