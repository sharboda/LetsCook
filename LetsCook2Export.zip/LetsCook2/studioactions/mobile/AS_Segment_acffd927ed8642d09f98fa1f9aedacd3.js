function AS_Segment_acffd927ed8642d09f98fa1f9aedacd3(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}