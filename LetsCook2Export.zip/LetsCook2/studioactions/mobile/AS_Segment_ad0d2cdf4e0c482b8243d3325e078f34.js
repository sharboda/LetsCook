function AS_Segment_ad0d2cdf4e0c482b8243d3325e078f34(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}