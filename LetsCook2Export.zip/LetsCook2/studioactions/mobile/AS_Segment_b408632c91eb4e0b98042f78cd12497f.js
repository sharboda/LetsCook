function AS_Segment_b408632c91eb4e0b98042f78cd12497f(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}