function AS_Segment_b95720fcb1034a25b4e6bb444a9eb467(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}