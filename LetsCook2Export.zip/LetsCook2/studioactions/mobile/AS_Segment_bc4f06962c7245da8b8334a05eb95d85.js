function AS_Segment_bc4f06962c7245da8b8334a05eb95d85(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}