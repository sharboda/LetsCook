function AS_Segment_cfa1e92cec4844bea43137e0cf6796f2(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}