function AS_Segment_d27cf0cbbd09463da0918922753d0514(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}