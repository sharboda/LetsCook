function AS_Segment_d67f09102d8f4b7db587e3276235528b(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}