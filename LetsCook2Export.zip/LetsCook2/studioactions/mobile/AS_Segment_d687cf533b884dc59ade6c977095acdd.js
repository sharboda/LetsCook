function AS_Segment_d687cf533b884dc59ade6c977095acdd(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}