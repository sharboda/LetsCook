function AS_Segment_daa3be9447464852a7912ff53690fa68(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}