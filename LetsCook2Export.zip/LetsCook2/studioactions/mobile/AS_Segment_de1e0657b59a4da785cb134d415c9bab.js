function AS_Segment_de1e0657b59a4da785cb134d415c9bab(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}