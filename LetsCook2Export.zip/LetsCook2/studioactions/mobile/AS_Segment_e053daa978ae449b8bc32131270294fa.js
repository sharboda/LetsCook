function AS_Segment_e053daa978ae449b8bc32131270294fa(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}