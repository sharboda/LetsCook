function AS_Segment_e8f4497072f340a4a9939a283393fdca(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}