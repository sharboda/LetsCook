function AS_Segment_e941bd976dda45f1ba0b33081d88f53b(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}