function AS_Segment_ea854640af054533943a1476062dc293(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}