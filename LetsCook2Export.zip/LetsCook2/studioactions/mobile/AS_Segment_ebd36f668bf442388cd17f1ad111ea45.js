function AS_Segment_ebd36f668bf442388cd17f1ad111ea45(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}