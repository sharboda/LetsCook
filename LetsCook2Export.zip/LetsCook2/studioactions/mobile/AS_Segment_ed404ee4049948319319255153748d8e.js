function AS_Segment_ed404ee4049948319319255153748d8e(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}