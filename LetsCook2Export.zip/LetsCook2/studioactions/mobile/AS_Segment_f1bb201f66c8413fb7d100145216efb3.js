function AS_Segment_f1bb201f66c8413fb7d100145216efb3(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}