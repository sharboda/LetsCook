function AS_Segment_f8e5f96fdc5a4ccd896297d9403f7e25(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}