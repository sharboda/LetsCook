function AS_Segment_gdbd74a4ed6545eab88fcc7af14d31aa(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}