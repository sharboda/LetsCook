function AS_Segment_hdf2ca9d1ddc48eb88a5de132bf0beb5(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}