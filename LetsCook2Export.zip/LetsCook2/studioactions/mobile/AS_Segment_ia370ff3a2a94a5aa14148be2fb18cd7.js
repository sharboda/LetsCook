function AS_Segment_ia370ff3a2a94a5aa14148be2fb18cd7(eventobject, sectionNumber, rowNumber) {
    return navigateOnSelected.call(this, frmRecipeList.segmentlist.selectedItems[0]);
}