function AS_Segment_ifb72c51d59b4e2f95398cb5b255ec11(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}