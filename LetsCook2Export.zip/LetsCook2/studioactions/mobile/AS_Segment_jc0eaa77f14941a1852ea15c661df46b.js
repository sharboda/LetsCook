function AS_Segment_jc0eaa77f14941a1852ea15c661df46b(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}