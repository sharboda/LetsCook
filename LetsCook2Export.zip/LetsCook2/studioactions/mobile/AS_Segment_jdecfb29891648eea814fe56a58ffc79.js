function AS_Segment_jdecfb29891648eea814fe56a58ffc79(eventobject, sectionNumber, rowNumber) {
    return onRowClickCallBck.call(this, null, null, rowNumber, null);
}