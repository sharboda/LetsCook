function AS_TextField_g83306eb5471400597a108e79ae8e194(eventobject, changedtext) {
    return parseTextBoxAndShowConfirm.call(this);
}